package fr.ordinalteam.ordinalteamweb.model;

public enum RoleName {
    USER,
    BOOSTER,
    MODERATOR,
    ADMINISTRATOR
}
