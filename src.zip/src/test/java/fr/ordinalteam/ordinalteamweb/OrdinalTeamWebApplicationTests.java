package fr.ordinalteam.ordinalteamweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdinalTeamWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
